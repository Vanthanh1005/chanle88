<?php
define('SERVERNAME','localhost');
define('USERNAME','clmmme17_clmm17me');
define('PASSWORD','clmmme17_clmm17me');
define('DATABASE','clmmme17_clmm17me');
?>