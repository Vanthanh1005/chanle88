<?php

include "momo.php";
 $timestamp = time();
 $t= date("H:i", $timestamp);
 



if($t== "23:59"){
  $CRON_MOMO = $VIP->get_row(" SELECT * FROM `cron_momo` ");
  $VIP->query("UPDATE `cron_momo` SET `today` = '0', `today_gd` = '0'");
  
  echo "reset thành công";
  exit();
}else{
    
  echo"reset thất bại , mới có $t giờ";
  exit();}