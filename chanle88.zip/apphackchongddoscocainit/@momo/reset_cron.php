<?php
if (file_exists('cron.txt')) 
{
    
    
unlink('cron.txt');
    
    
    
}